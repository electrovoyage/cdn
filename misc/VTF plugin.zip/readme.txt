installing:
drop the contents of the FileTypes folder of this archive into your <PDN>/FileTypes folder (replace <PDN> with the folder your Paint.NET is installed to).